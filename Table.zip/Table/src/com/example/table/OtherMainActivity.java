package com.example.table;

import java.util.ArrayList;

import android.os.Bundle;
import android.app.Activity;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.Menu;
import android.view.ViewGroup.LayoutParams;
import android.widget.LinearLayout;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

public class OtherMainActivity extends Activity {

	

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_other_main);
		
		
		
		
		ArrayList<Tablerow> tabarr=new ArrayList<Tablerow>();
		
		Tablerow t1=new Tablerow("USD", 0.154, -0.123, 1, 0.2, 1.554, 1.564);
		Tablerow t2=new Tablerow("USD", -0.154, 0.123, 1, 0.2, 1.554, 1.564);
		Tablerow t3=new Tablerow("USD", 0.154, -0.123, 1, 0.0, 1.554, 1.564);
		tabarr.add(t1);
		tabarr.add(t2);
		tabarr.add(t3);
		
		
	
		TableLayout t=(TableLayout) findViewById(R.id.table);
		for(int i=0;i<3;i++)
			
		{
			Tablerow tr=tabarr.get(i);
			TableRow tabr=new TableRow(getBaseContext());
			TableRow.LayoutParams lp = new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT,TableRow.LayoutParams.FILL_PARENT);
		     tabr.setLayoutParams(lp);
			tabr.setBackgroundResource(R.drawable.lightgrey);
			tabr.setWeightSum(57);
			
				TextView tv1=Createview(7, tr.cur,"cur");
				tabr.addView(tv1, 0);
				
				
				//LinearLayout.LayoutParams llp2=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv2=Createview(10, tr.pos1,"pos1");
				tabr.addView(tv2,1);
				
				
				//LinearLayout.LayoutParams llp3=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv3=Createview(10, tr.pos2,"pos2");
				
				tabr.addView(tv3,2);
				
				
				//LinearLayout.LayoutParams llp4=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
				TextView tv4=Createview(5, tr.age,"age");
				
				tabr.addView(tv4,3);
				
				
				
				//LinearLayout.LayoutParams llp5=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 5);
				TextView tv5=Createview(5, tr.pnl,"pnl");
				tabr.addView(tv5,4);
				
				//LinearLayout.LayoutParams llp6=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv6=Createview(10, tr.book,"book");
				
				tabr.addView(tv6,5);
				
				//LinearLayout.LayoutParams llp7=new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.FILL_PARENT, 10);
				TextView tv7=Createview(10, tr.mkt,"mrk");
				
				tabr.addView(tv7,6);
				
				
				t.addView(tabr);
				
			
			
			
			
		}
		
		
		
		
		
	}
	
	TextView Createview(int weight,Object txtvalue,String feild){
		
		TextView tv1=new TextView(this);
		//LinearLayout.LayoutParams llp1 = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT,weight);
					tv1.setText(txtvalue+"");
						tv1.setBackgroundResource(R.drawable.lightgrey);
						tv1.setGravity(Gravity.CENTER);
						if(feild.equals("pos1")&& (Double)txtvalue<0  )
						tv1.setTextColor(getResources().getColor(R.color.red));
						else
							tv1.setTextColor(getResources().getColor(R.color.white));
						
						if(feild.equals("pos2")&& (Double)txtvalue<0  )
							tv1.setTextColor(getResources().getColor(R.color.red));
							else
								tv1.setTextColor(getResources().getColor(R.color.white));
						
						
						
						
						if(feild.equals("pnl")&& (Double)txtvalue<=0  )
							tv1.setBackgroundResource(R.drawable.red);
						else
							
							tv1.setBackgroundResource(R.drawable.lightgrey);
						
						
						//tv1.setLayoutParams(llp1);
						
						
						return tv1;
				}
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.other_main, menu);
		return true;
	}

}
