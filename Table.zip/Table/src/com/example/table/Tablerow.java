package com.example.table;

public class Tablerow {

	
	String cur;
	double pos1;
	double pos2;
	
	int age;
	double pnl;
	double book;
	double mkt;
	 
	public Tablerow(String cur, double pos1, double pos2, int age, double pnl,
			double book, double mkt) {
		super();
		this.cur = cur;
		this.pos1 = pos1;
		this.pos2 = pos2;
		this.age = age;
		this.pnl = pnl;
		this.book = book;
		this.mkt = mkt;
	}
	
	
}

